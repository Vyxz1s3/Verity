import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { successEmbed, warningEmbed } from '../../utils/embeds.js';
import { logModerationAction } from '../../utils/moderation.js';
import { logger } from '../../utils/logger.js';
import { InteractionHelper } from '../../utils/interactionHelper.js';
import { ModerationService } from '../../services/moderationService.js';
import { handleInteractionError } from '../../utils/errorHandler.js';

export default {
    data: new SlashCommandBuilder()
        .setName('infraction')
        .setDescription('Issue an infraction (strike) against a member')
        .addUserOption((option) =>
            option
                .setName('target')
                .setDescription('The member to infract')
                .setRequired(true),
        )
        .addStringOption((option) =>
            option
                .setName('reason')
                .setDescription('Reason for the infraction')
                .setRequired(true),
        )
        .addStringOption((option) =>
            option
                .setName('severity')
                .setDescription('Severity level of the infraction')
                .addChoices(
                    { name: 'Low', value: 'low' },
                    { name: 'Medium', value: 'medium' },
                    { name: 'High', value: 'high' },
                ),
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
    category: 'moderation',

    async execute(interaction, config, client) {
        try {
            const user = interaction.options.getUser('target');
            const reason = interaction.options.getString('reason');
            const severity = interaction.options.getString('severity') || 'low';

            if (user.id === interaction.user.id) {
                throw new Error('You cannot issue an infraction against yourself.');
            }
            if (user.id === client.user.id) {
                throw new Error('You cannot issue an infraction against the bot.');
            }

            const member = await interaction.guild.members.fetch(user.id).catch(() => null);
            if (!member) {
                throw new Error('That user is not in this server.');
            }

            const result = await ModerationService.warnUser({
                guild: interaction.guild,
                user,
                moderator: interaction.member,
                reason,
            });

            await logModerationAction({
                guild: interaction.guild,
                action: 'Infraction',
                target: user,
                moderator: interaction.user,
                reason,
                extra: `Severity: ${severity.charAt(0).toUpperCase() + severity.slice(1)} | Case ID: #${result.caseId}`,
            });

            const severityEmoji = { low: '🟡', medium: '🟠', high: '🔴' }[severity];

            await InteractionHelper.universalReply(interaction, {
                embeds: [
                    warningEmbed(
                        `${severityEmoji} **Infraction Issued** — ${user.tag}`,
                        `**Reason:** ${reason}\n**Severity:** ${severity.charAt(0).toUpperCase() + severity.slice(1)}\n**Issued by:** ${interaction.user.tag}\n**Case ID:** #${result.caseId}`,
                    ),
                ],
            });

            try {
                await user.send({
                    embeds: [
                        warningEmbed(
                            `${severityEmoji} You received an infraction in **${interaction.guild.name}**`,
                            `**Reason:** ${reason}\n**Severity:** ${severity.charAt(0).toUpperCase() + severity.slice(1)}\n**Case ID:** #${result.caseId}`,
                        ),
                    ],
                });
            } catch {
                logger.warn(`Could not DM infraction notice to ${user.tag} — DMs may be closed.`);
            }
        } catch (error) {
            logger.error('Infraction command error:', error);
            await handleInteractionError(interaction, error, { subtype: 'infraction_failed' });
        }
    },
};
