import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { successEmbed, errorEmbed } from '../../utils/embeds.js';
import { logModerationAction } from '../../utils/moderation.js';
import { logger } from '../../utils/logger.js';
import { InteractionHelper } from '../../utils/interactionHelper.js';
import { handleInteractionError } from '../../utils/errorHandler.js';

export default {
    data: new SlashCommandBuilder()
        .setName('promote')
        .setDescription('Promote a member to a new role')
        .addUserOption((option) =>
            option
                .setName('target')
                .setDescription('The member to promote')
                .setRequired(true),
        )
        .addRoleOption((option) =>
            option
                .setName('role')
                .setDescription('The role to promote the member to')
                .setRequired(true),
        )
        .addStringOption((option) =>
            option
                .setName('reason')
                .setDescription('Reason for the promotion'),
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),
    category: 'moderation',

    async execute(interaction, config, client) {
        try {
            const user = interaction.options.getUser('target');
            const role = interaction.options.getRole('role');
            const reason = interaction.options.getString('reason') || 'No reason provided';

            if (user.id === interaction.user.id) {
                throw new Error('You cannot promote yourself.');
            }
            if (user.id === client.user.id) {
                throw new Error('You cannot promote the bot.');
            }

            const member = await interaction.guild.members.fetch(user.id);
            if (!member) {
                throw new Error('That user is not in this server.');
            }

            if (member.roles.cache.has(role.id)) {
                throw new Error(`${user.tag} already has the ${role.name} role.`);
            }

            const botMember = await interaction.guild.members.fetchMe();
            if (role.position >= botMember.roles.highest.position) {
                throw new Error('I cannot assign a role that is higher than or equal to my highest role.');
            }

            if (role.position >= interaction.member.roles.highest.position) {
                throw new Error('You cannot assign a role that is higher than or equal to your highest role.');
            }

            await member.roles.add(role, `Promoted by ${interaction.user.tag}: ${reason}`);

            await logModerationAction({
                guild: interaction.guild,
                action: 'Promotion',
                target: user,
                moderator: interaction.user,
                reason,
                extra: `Role: ${role.name}`,
            });

            await InteractionHelper.universalReply(interaction, {
                embeds: [
                    successEmbed(
                        `⬆️ **Promoted** ${user.tag}`,
                        `**New Role:** ${role}\n**Reason:** ${reason}\n**Promoted by:** ${interaction.user.tag}`,
                    ),
                ],
            });
        } catch (error) {
            logger.error('Promote command error:', error);
            await handleInteractionError(interaction, error, { subtype: 'promote_failed' });
        }
    },
};
